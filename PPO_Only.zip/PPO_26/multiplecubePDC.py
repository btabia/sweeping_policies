from utils.basetask import Basetask
from utils.PDController import PDController
from utils.sweepingplanner import SweepingPlanner

#
#from omni.isaac.core.prims import XFormPrim, RigidPrim
import math
import quaternion


import numpy as np

class MultipleCubePDC(Basetask):
    def __init__(self, config_task):
        self.cfg = config_task
        self.num_debris = self.cfg["env"]["num_debris"]
        self.prev_time = 0
        self.prev_debris_target_dist = np.zeros(self.num_debris, dtype=np.float32)
        self.prev_brush_debris_dist = np.zeros(self.num_debris, dtype=np.float32)
        self.motion_controller = PDController()
        linear_proportional_gain = np.array(self.cfg["env"]["task"]["controller"]["linear_proportional_gain"])
        angular_proportional_gain = np.array(self.cfg["env"]["task"]["controller"]["angular_proportional_gain"])
        linear_derivative_gain = np.array(self.cfg["env"]["task"]["controller"]["linear_derivative_gain"])
        angular_derivative_gain = np.array(self.cfg["env"]["task"]["controller"]["angular_derivative_gain"])
        self.motion_controller.setProportionalGain(linear_proportional_gain, angular_proportional_gain)
        self.motion_controller.setDerivativeGain(linear_derivative_gain, angular_derivative_gain)
        
        self.cumul_reward = 0
        self.play = False

        # individual reward setting for plotting
        self.nb_reward = 4
        self.nb_error = 4
        self.rewards_cumul = [0,0,0,0]
        self.rewards = []

        self.error_cumul = [0,0,0,0]
        self.errors = []

        self.brush_debris_pos_cumul = np.zeros(self.num_debris)
        self.brush_debris_speed_cumul = np.zeros(self.num_debris)

        self.debris_target_pos_cumul = np.zeros(self.num_debris)
        self.debris_target_speed_cumul = np.zeros(self.num_debris)

    
    def reset_log_value(self):
        self.rewards_cumul = [0,0,0,0]
        self.rewards = []

        self.error_cumul = [0,0,0,0]
        self.errors = []

        self.brush_debris_pos_cumul = np.zeros(self.num_debris)
        self.brush_debris_speed_cumul = np.zeros(self.num_debris)

        self.debris_target_pos_cumul = np.zeros(self.num_debris)
        self.debris_target_speed_cumul = np.zeros(self.num_debris)


    def set_data_logger(self, data_logger):
        self.data_logger = data_logger
        self.play = True

    def set_logging_path(self, logging_path): 
        self.set_logging_path = logging_path
    

    def set_dynamic_control_interface(self, dc_interface):
        self.dc_interface = dc_interface

    def set_up_scene(self, world):
        self._world = world
        self.brush = self.include_brush(world)
        self.debris_list = self.include_debris(world)
        self.target = self.include_target(world)
        # set up dynamic control interface for brush handle
        self.brush_dc = self.dc_interface.get_rigid_body(self.cfg["env"]["task"]["handle_prim_path"])
        

    def include_brush(self, world):
        from omni.isaac.core.utils.stage import add_reference_to_stage
        from omni.isaac.core.prims import XFormPrim, RigidPrim
        brush = add_reference_to_stage(self.cfg["env"]["task"]["brush_usd_path"], 
                                self.cfg["env"]["task"]["brush_prim_path"])
        world.reset()
        handle =  RigidPrim(
                prim_path = self.cfg["env"]["task"]["handle_prim_path"]
            )  
        return handle

    def include_debris(self, world):
        from omni.isaac.core.objects import DynamicCuboid
        debris_list = []
        self.debris_dist = self.cfg["env"]["task"]["reset"]["base_debris_dist"]
        for i in range(self.num_debris):
            init_debris_pos = np.array(self.cfg["env"]["task"]["debris_init_pos"])
            debris_list.append( world.scene.add(
                DynamicCuboid(
                    prim_path="/World/Debris_" + str(i),
                    name="debris_" + str(i),
                    position= init_debris_pos,
                    scale=np.array(self.cfg["env"]["task"]["debris_scale"]),
                    color=np.array(self.cfg["env"]["task"]["debris_color"]),
                )
            ))
            world.reset()
        return debris_list

    def include_target(self, world):
        from omni.isaac.core.objects import VisualCylinder
        target = world.scene.add(
            VisualCylinder(
                prim_path="/World/Target",
                name="target",
                position= np.array(self.cfg["env"]["task"]["target_init_pos"]),
                scale=np.array(self.cfg["env"]["task"]["target_scale"]),
                color=np.array(self.cfg["env"]["task"]["target_color"]),
                radius = self.cfg["env"]["task"]["target_radius"],
                height = self.cfg["env"]["task"]["target_height"]
            )
        )
        world.reset()
        return target


    def get_observations(self):
        # capture position
        brush_position, self.brush_orientation = self.brush.get_world_pose()
        target_position, _ = self.target.get_world_pose()
        debris_positions = np.zeros(self.num_debris * 3, dtype=np.float32)

        target_rel_pos = np.subtract(brush_position, target_position)


        # capture velocities
        brush_lin_vel_carb = self.dc_interface.get_rigid_body_linear_velocity(self.brush_dc)
        brush_ang_vel_carb = self.dc_interface.get_rigid_body_angular_velocity(self.brush_dc)
        brush_lin_vel = np.array([brush_lin_vel_carb[0], brush_lin_vel_carb[1], brush_lin_vel_carb[2]])
        brush_ang_vel = np.array([brush_ang_vel_carb[0],brush_ang_vel_carb[1], brush_ang_vel_carb[2]])
        target_lin_vel = np.zeros(3)
        target_rel_vel = np.subtract(brush_lin_vel, target_lin_vel)
        debris_lin_vels = np.zeros(self.num_debris * 3, dtype=np.float32)

        brush_debris_pos = np.zeros(self.num_debris * 3, dtype=np.float32) # single distance
        debris_target_pos = np.zeros(self.num_debris * 3, dtype=np.float32) # 
        brush_debris_vels = np.zeros(self.num_debris * 3, dtype=np.float32)
        debris_target_vels = np.zeros(self.num_debris * 3, dtype=np.float32)
        self.brush_debris_dist_list = np.zeros(self.num_debris, dtype=np.float32)
        self.brush_debris_vels_list = np.zeros(self.num_debris, dtype=np.float32)
        self.debris_target_dist_list = np.zeros(self.num_debris, dtype=np.float32)
        self.debris_target_vels_list = np.zeros(self.num_debris, dtype=np.float32)
        self.delta_debris_target = np.zeros(self.num_debris, dtype=np.float32)
        self.delta_brush_debris = np.zeros(self.num_debris, dtype=np.float32)

        self.current_time = self._world.current_time
        self.time_step = self.current_time - self.prev_time
        self.prev_time = self.current_time
        for i in range(self.num_debris):
            debris_pos, _ = self.debris_list[i].get_world_pose()
            debris_lin_vel = self.debris_list[i].get_linear_velocity()
            for j in range(3):
                debris_positions[(i * 3) + j] = debris_pos[j]
                debris_lin_vels[(i * 3) + j] = debris_lin_vel[j]
                brush_debris_pos[(i * 3) + j] = debris_pos[j] - brush_position[j]
                debris_target_pos[(i * 3) + j] = target_position[j] - debris_pos[j]
                brush_debris_vels[(i * 3) + j] = debris_lin_vel[j] - brush_lin_vel[j]
                debris_target_vels[(i * 3) + j] = target_lin_vel[j] - debris_lin_vel[j]
            # other observations not sent to the agent, but rather for rewards
            self.brush_debris_dist_list[i] = np.sqrt(pow(brush_debris_pos[(i * 3)  + 0],2) + pow(brush_debris_pos[(i * 3) + 1],2) + pow(brush_debris_pos[(i * 3) + 2],2))
            self.debris_target_dist_list[i] = np.sqrt(pow(debris_target_pos[(i * 3) + 0],2) + pow(debris_target_pos[(i * 3) + 1],2))
            self.delta_debris_target[i] = self.prev_debris_target_dist[i] - self.debris_target_dist_list[i] 
            self.debris_target_vels_list[i] = self.delta_debris_target / self.time_step
            self.delta_brush_debris[i] = self.prev_brush_debris_dist[i]  - self.brush_debris_dist_list[i]
            self.brush_debris_vels_list[i] = self.delta_brush_debris / self.time_step

            self.brush_debris_pos_cumul[i] = self.brush_debris_pos_cumul[i] + self.brush_debris_dist_list[i]
            self.brush_debris_speed_cumul[i] = self.brush_debris_speed_cumul[i] + self.brush_debris_vels_list[i] 

            self.debris_target_pos_cumul[i] = self.debris_target_pos_cumul[i] + self.debris_target_dist_list[i]
            self.debris_target_speed_cumul[i] = self.debris_target_speed_cumul[i] + self.debris_target_vels_list[i]

        self.prev_debris_target_dist = self.debris_target_dist_list
        self.prev_brush_debris_dist = self.brush_debris_dist_list

        # brush orientation for rewards
        from omni.isaac.core.utils.rotations import quat_to_euler_angles
        brush_orientation_euler = quat_to_euler_angles(self.brush_orientation, degrees = True)
        self.roll = brush_orientation_euler[0]
        self.pitch = brush_orientation_euler[1]
        self.yaw = brush_orientation_euler[2]

        # setting up observation for PD controller
        self.motion_controller.setPositionsObservation(linear_position_observation= brush_position,
                                                angular_position_observation=  self.brush_orientation)

        self.motion_controller.setVelocitiesObservation(linear_velocity_observation = brush_lin_vel, 
                                                    angular_velocity_observation = brush_ang_vel)

        def frame_logging_func(tasks, scene):
            return {
                "brush_linear_positions": brush_position.tolist(), 
                "brush_angular_positions": brush_orientation_euler.tolist(),
                "brush_linear_velocities": brush_lin_vel.tolist(), 
                "brush_angular_velocities": brush_ang_vel.tolist(), 
                "debris_positions": self.debris_list[0].get_world_pose()[0].tolist(),
                "debris_velocities": self.debris_list[0].get_linear_velocity().tolist(),
                    
            }

        if self.play == True: 
                self.data_logger.add_data_frame_logging_func(frame_logging_func) # adds the function to be called at each physics time step.
                self.data_logger.start() # starts the data logging
                                                

        obs = np.concatenate(
            [
                self.brush_orientation, 
                brush_ang_vel, 
                brush_debris_pos, 
                brush_debris_vels, 
                target_rel_pos, 
                target_rel_vel
            ]
        )

        return obs


    def save_logged_data(self, log_path):
        self.data_logger.save(log_path = log_path)
        self.data_logger.reset()
        return
        

    def reset(self):
        
        self.cumul_reward = 0
        if self.cfg["env"]["task"]["reset"]["randomise_target"] == True :
            self.target_dist = self.cfg["env"]["task"]["reset"]["base_target_dist"]
            self.target_dist_x = (np.random.rand() * self.target_dist * 2) - self.target_dist 
            self.target_dist_y = (np.random.rand() * self.target_dist * 2) - self.target_dist
            new_target_pos = np.array([self.target_dist_x, self.target_dist_y, 0.06])
            self.target.set_world_pose(new_target_pos, np.array([1,0,0,0]))

        if self.cfg["env"]["task"]["reset"]["randomise_debris"] == True :
            for i in range(self.num_debris):
                self.debris_dist = self.cfg["env"]["task"]["reset"]["base_debris_dist"]
                self.debris_dist_x = (np.random.rand() * self.debris_dist * 2) - self.debris_dist 
                self.debris_dist_y = (np.random.rand() * self.debris_dist * 2) - self.debris_dist
                new_debris_pos = np.array([self.debris_dist_x, self.debris_dist_y, 0.06])
                self.debris_list[i].set_world_pose(new_debris_pos, np.array([1,0,0,0]))
        return

    def is_done(self, done):
        done = True
        d = False
        for i in range(self.num_debris):
            target_scale_vector = np.array(self.cfg["env"]["task"]["target_scale"])
            target_scale = (target_scale_vector[0] + target_scale_vector[1]) / 2
            if self.debris_target_dist_list[i] < (self.cfg["env"]["task"]["target_radius"] * target_scale):
                d = True
            else:
                d = False
            done = d & done
        return done


    def perform_action(self, action):
        from omni.isaac.core.utils.numpy.rotations import euler_angles_to_quats
        from omni.isaac.core.utils.rotations import quat_to_rot_matrix

        # Note for later: add an orientation and angle of attack rate action

        normal_force = action[0] * self.cfg["env"]["task"]["action"]["normal_force_scale"] # force in x-y axis
        shear_force = action[1] * self.cfg["env"]["task"]["action"]["shear_force_scale"] # force in z axis
        yaw_action = action[2] * self.cfg["env"]["task"]["action"]["yaw_scale"]# yaw orientation angle
        yaw_rate_action = action[3] * self.cfg["env"]["task"]["action"]["yaw_rate_scale"]# yaw orientation angle
        #pitch = action[4] * self.cfg["env"]["task"]["action"]["attack_angle_scale"] # pitch orientation angle
        #pitch_rate = action[5] * self.cfg["env"]["task"]["action"]["attack_angle_rate_scale"]

        lin_pos_command, _ = self.debris_list[0].get_world_pose()
        ang_pos_command = euler_angles_to_quats(np.array([0,0,yaw_action]), degrees= True)

        self.motion_controller.setPositionsCommand(lin_pos_command, ang_pos_command)

        lin_vel_command = self.debris_list[0].get_linear_velocity()
        ang_vel_command = np.array([0,0, yaw_rate_action])
        self.motion_controller.setVelocitiesCommand(lin_vel_command, ang_vel_command)

        forces, moments = self.motion_controller.getForceTorque()

        #rotation_matrix = quat_to_rot_matrix(self.brush_orientation)
        #ff_force = np.array([normal_force, 0, shear_force]) 

        brush_forces = np.zeros(3)
        brush_forces[0] = normal_force * np.cos(yaw_action) #+ forces[0]
        brush_forces[1] = normal_force * np.sin(yaw_action) #+ forces[1]
        brush_forces[2] = shear_force #+ forces[2]
        #brush_forces = forces + np.matmul(rotation_matrix, ff_force)

        self.dc_interface.apply_body_force(self.brush_dc,
                            brush_forces, 
                            np.array([0,0,0]), #force point of application
                            False) # true: local frame / false: global frame

        self.dc_interface.apply_body_torque(self.brush_dc,
                                            moments,
                                            False)

        


    def calculate_metrics(self):
        # reward 
        # for the reward between the brush and debris, the farthest it is between the target and debris, the highest the reward
        # define a table ranking the distance between target and debris and rank them
        target_scale_vector = np.array(self.cfg["env"]["task"]["target_scale"])
        target_scale = (target_scale_vector[0] + target_scale_vector[1]) / 2
        target_radius_gaussian = (self.cfg["env"]["task"]["target_radius"] * target_scale) / 2

        target_debris_vel_tolerance = (self.cfg["env"]["task"]["reward"]["debris_target_velocity_tolerance"])

        debris_scale_vector = np.array(self.cfg["env"]["task"]["debris_scale"])
        debris_scale = (debris_scale_vector[0] + debris_scale_vector[1]) / 2
        debris_radius_gaussian = self.cfg["env"]["task"]["reward"]["brush_debris_radius"]

        brush_debris_vel_tolerance = (self.cfg["env"]["task"]["reward"]["brush_debris_velocity_tolerance"])


        
        reward_debris_target = 0
        reward_brush_debris = 0
        #ranking = self.ranking
        ranking = np.argsort(-self.debris_target_dist_list)

        

        for i in range(self.num_debris):
            base_debris_target_scale  = self.cfg["env"]["task"]["reward"]["base_debris_target_scale"] - i

            target_debris_dist_weight = 30 #pow(10, base_debris_target_scale)
            target_debris_disp_weight = 20 #pow(10, (base_debris_target_scale))
            debris_brush_dist_weight = 10 #pow(10, (base_debris_target_scale))
            debris_brush_disp_weight = 1 #pow(10, (base_debris_target_scale))

            #print(" --- reward scales ---")
            #print("target_debris_dist_weight: " + str(target_debris_dist_weight))
            #print("target_debris_disp_weight: " + str(target_debris_disp_weight))
            #print("debris_brush_dist_weight: " + str(debris_brush_dist_weight))
            #print("debris_brush_disp_weight: " + str(debris_brush_disp_weight))

            #debris to target disp delta
            reward_debris_target_vel_delta = target_debris_disp_weight * self.delta_debris_target[i]#target_debris_disp_weight * (np.exp((-pow(self.debris_target_vels_list[ranking[i]] - self.cfg["env"]["task"]["reward"]["debris_target_velocity"],2))/(2*pow(target_debris_vel_tolerance,2))))
            self.rewards_cumul[2] = reward_debris_target_vel_delta + self.rewards_cumul[2]

            dt_speed_error = self.debris_target_vels_list[ranking[i]] - self.cfg["env"]["task"]["reward"]["debris_target_velocity"]
            self.error_cumul[2] = dt_speed_error + self.error_cumul[2]

            #debris to target dist
            reward_debris_target_dist_delta = target_debris_dist_weight * (np.exp((-pow(self.debris_target_dist_list[ranking[i]],2))/(2*pow(target_radius_gaussian,2))))
            self.rewards_cumul[3] = reward_debris_target_dist_delta + self.rewards_cumul[3]
            dt_pos_error = self.debris_target_dist_list[ranking[i]]
            self.error_cumul[3] = dt_pos_error + self.error_cumul[3]

            reward_debris_target =  reward_debris_target_vel_delta + reward_debris_target_dist_delta + reward_debris_target

            #brush to debris velocity
            reward_brush_debris_vel_delta = debris_brush_disp_weight * self.delta_brush_debris[i]#debris_brush_disp_weight * (np.exp((-pow(self.brush_debris_vels_list[ranking[i]] - self.cfg["env"]["task"]["reward"]["brush_debris_velocity"],2))/(2*pow(brush_debris_vel_tolerance,2))))
            self.rewards_cumul[0] = reward_brush_debris_vel_delta + self.rewards_cumul[0]
            bt_speed_error = self.brush_debris_vels_list[ranking[i]] - self.cfg["env"]["task"]["reward"]["brush_debris_velocity"]
            self.error_cumul[0] = bt_speed_error + self.error_cumul[0]
            #print("self.brush_debris_vels_list[ranking[i]]: " + str(self.brush_debris_vels_list[ranking[i]]))
            #print("reward_brush_debris_vel_delta: " + str(reward_brush_debris_vel_delta))
            #brush to debris dist
            reward_brush_debris_dist_delta = debris_brush_dist_weight * (np.exp((-pow(self.brush_debris_dist_list[ranking[i]],2))/(2*pow(debris_radius_gaussian,2))))
            self.rewards_cumul[1] = reward_brush_debris_dist_delta + self.rewards_cumul[1]
            bt_pos_error = self.brush_debris_dist_list[ranking[i]]
            self.error_cumul[1] = bt_pos_error + self.error_cumul[1]
            #print("reward_brush_debris_dist_delta: " + str(reward_brush_debris_dist_delta))
            self.rewards.append([reward_brush_debris_vel_delta, 
                                    reward_brush_debris_dist_delta, 
                                    reward_debris_target_vel_delta,
                                    reward_debris_target_dist_delta])
            self.errors.append([bt_speed_error, bt_pos_error, dt_speed_error, dt_pos_error])
            
            reward_brush_debris = reward_brush_debris + reward_brush_debris_vel_delta + reward_brush_debris_dist_delta
    
        reward = reward_debris_target + reward_brush_debris
        self.cumul_reward = self.cumul_reward + reward
        #print("cumul_reward: " + str(self.cumul_reward))

        return reward