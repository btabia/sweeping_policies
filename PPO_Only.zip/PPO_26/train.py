
from stable_baselines3 import PPO 
from stable_baselines3.ppo import MlpPolicy
from stable_baselines3.common.callbacks import CheckpointCallback
from stable_baselines3.common.callbacks import CallbackList
from stable_baselines3.common.callbacks import BaseCallback
#from stable_baselines3.common.schedules import LinearSchedule
from tasks.singlecube import SingleCube
from utils.superenv import SuperEnv
from utils.task_selector import taskselector

#from callback import GetDataCallback
import torch as th
import numpy as np
import argparse
from typing import Callable
import datetime
import os
import shutil
import sys
import hydra
from omegaconf import DictConfig, OmegaConf

parser = argparse.ArgumentParser()
parser.add_argument("--test", default=False, action="store_true", help="Run in test mode")
args, unknown = parser.parse_known_args()

class TensorboardCallback(BaseCallback):
    """
    Custom callback for plotting additional values in tensorboard.
    """

    def __init__(self, env, verbose=0):
        self.env  = env
        super().__init__(verbose)

    def _on_step(self) -> bool:
        return True

    def _on_rollout_end(self) -> bool:
        reward_means = self.env.get_reward_means()
        reward_std = self.env.get_reward_std()
        error_means = self.env.get_error_means()
        error_std = self.env.get_error_std()
        brush_debris_pos = self.env.get_brush_debris_mean_position()
        #brush_debris_speed = self.env.get_brush_debris_mean_speed()
        debris_target_pos = self.env.get_debris_target_mean_position()
        #debris_target_speed = self.env.get_debris_target_mean_speed()

        for i in range(len(reward_means)):
            self.logger.record("rewards/reward_mean_" + str(i), reward_means[i])
        for i in range(len(reward_std)):
            self.logger.record("rewards/reward_std_" + str(i), reward_std[i])
        for i in range(len(error_means)):
            self.logger.record("errors/error_means_" + str(i), error_means[i])
        for i in range(len(error_std)):
            self.logger.record("errors/error_std_" + str(i), error_std[i])
        for i in range(len(brush_debris_pos)):
            self.logger.record("observations/bd_pos_mean_" + str(i), brush_debris_pos[i])
        #for i in range(len(brush_debris_speed)):
        #    self.logger.record("observations/bd_speed_mean_" + str(i), brush_debris_speed[i])
        for i in range(len(debris_target_pos)):
            self.logger.record("observations/dt_pos_mean_" + str(i), debris_target_pos[i])
        #for i in range(len(debris_target_speed)):
         #   self.logger.record("observations/dt_speed_mean_" + str(i), debris_target_speed[i])
        
        self.env.reset_log_value()

        return True
    
    

def linear_schedule(initial_value: float) -> Callable[[float], float]:
    """
    Linear learning rate schedule.

    :param initial_value: Initial learning rate.
    :return: schedule that computes
      current learning rate depending on remaining progress
    """
    def func(progress_remaining: float) -> float:
        """
        Progress will decrease from 1 (beginning) to 0.

        :param progress_remaining:
        :return: current learning rate
        """
        return progress_remaining * initial_value

    return func

def training(cfg, env, config_file_path) -> None:

    activation_map = {
        "Relu" : th.nn.ReLU,
        "Tanh" : th.nn.Tanh,
    }

    policy_type_map = {
        "MLP" : MlpPolicy
    }
    
    activation = th.nn.ReLU
    vf_nn = OmegaConf.to_container(cfg["training"]["policy_kwargs"]["nn_config"]["value_function"])
    policy_nn = OmegaConf.to_container(cfg["training"]["policy_kwargs"]["nn_config"]["policy"])
    policy_kwargs = dict(activation_fn = activation, net_arch=[dict(vf= vf_nn, pi= policy_nn)])
    policy = MlpPolicy
    total_timesteps = cfg["training"]["max_timestep"]
    saving_freq = cfg["training"]["checkpoint"]["saving_freq"]
    base_dir = cfg["training"]["checkpoint"]["base_directory"]
    exit = False
    iteration = 1
    saving_path = base_dir + "/PPO_" + str(iteration)
    while exit == False:
        folder_exist = os.path.exists(saving_path)
        if folder_exist == False: 
            os.makedirs(saving_path)
            exit = True
        elif folder_exist == True:
            iteration = iteration + 1
            saving_path = base_dir + "/PPO_" + str(iteration)
    name_prefix = "checkpoint"

    print("log and policy saving path:" + saving_path)
    checkpoint_callback = CheckpointCallback(save_freq = saving_freq, save_path = saving_path + "/checkpoints", name_prefix = name_prefix)
    tensorboard_callback = TensorboardCallback(env)
    callback_list = CallbackList([checkpoint_callback, tensorboard_callback])
    # save file for record and replay

    shutil.copyfile("/home/btabia/git/ori/virtual-decontamination/cfg/multiplecubePDC.yaml", saving_path + "/config.yaml")
    shutil.copyfile("/home/btabia/git/ori/virtual-decontamination/tasks/multiplecubePDC.py", saving_path + "/multiplecubePDC.py")
    shutil.copyfile("/home/btabia/git/ori/virtual-decontamination/scripts/train.py", saving_path + "/train.py")
    shutil.copyfile("/home/btabia/git/ori/virtual-decontamination/scripts/play.py", saving_path + "/play.py")
    
    model = PPO(
        policy, 
        env, 
        policy_kwargs=policy_kwargs,
        verbose = cfg["training"]["PPO"]["verbose"],
        n_steps = cfg["training"]["PPO"]["n_steps"],
        batch_size = cfg["training"]["PPO"]["batch_size"],
        learning_rate = linear_schedule(cfg["training"]["PPO"]["learning_rate"]),
        gamma = cfg["training"]["PPO"]["gamma"], 
        ent_coef = cfg["training"]["PPO"]["ent_coef"],
        clip_range = cfg["training"]["PPO"]["clip_range"], 
        n_epochs = cfg["training"]["PPO"]["n_epochs"],
        gae_lambda = cfg["training"]["PPO"]["gae_lambda"], 
        max_grad_norm = cfg["training"]["PPO"]["max_grad_norm"],
        vf_coef = cfg["training"]["PPO"]["vf_coef"],
        device = cfg["training"]["PPO"]["device"],
        #target_kl = cfg["training"]["PPO"]["target_kl"],
        tensorboard_log = saving_path,
    )    

    model.learn(total_timesteps=total_timesteps, callback=callback_list)

    model.save(saving_path + "/policy")

    env.close()

@hydra.main(config_name="multiplecubePDC", config_path="../cfg")
def parse_hydra_configs(cfg: DictConfig) -> None:
    
    time_str = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    cwd = os.getcwd()
    hydra_folder_path = cwd + "/.hydra"
    config_file_path = hydra_folder_path + "/config.yaml"

    task = taskselector(config=cfg)

    env = SuperEnv(cfg, task, headless=cfg["training"]["headless"])

    training(cfg = cfg, env = env, config_file_path=config_file_path)
    

if __name__ == '__main__':
    parse_hydra_configs()


