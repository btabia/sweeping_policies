from stable_baselines3 import PPO 

from tasks.singlecube import SingleCube
from tasks.multiplecube import MultipleCube
from utils.superenv import SuperEnv
from utils.task_selector import taskselector

import datetime
import os
import hydra
from omegaconf import DictConfig, OmegaConf


def play(cfg, env):

    model = PPO.load(cfg["play"]["policy_path"])
    deterministic = cfg["play"]["deterministic"]
    

    for _ in range(cfg["play"]["max_iteration"]):
        obs = env.reset()
        done = False
        cumul_reward = 0
        while not done: 
            actions, _ = model.predict(observation=obs, deterministic=deterministic)
            obs, reward, done, info = env.step(actions)
            print("instant reward: " + str(reward))
            cumul_reward = reward + cumul_reward
            print("cumulative reward: " + str(cumul_reward))
            env.render()

    env.close()

@hydra.main(config_name="multiplecubePDC", config_path="../cfg")
def parse_hydra_configs(cfg: DictConfig) -> None:
    time_str = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

    task = taskselector(config=cfg)

    env = SuperEnv(cfg, task, headless=False)

    play(cfg = cfg, env = env)
    

if __name__ == '__main__':
    parse_hydra_configs()